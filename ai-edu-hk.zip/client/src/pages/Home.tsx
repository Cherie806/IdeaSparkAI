import { useState, useEffect } from "react";

export default function Home() {
  const [scrolled, setScrolled] = useState(false);
  const [openFaq, setOpenFaq] = useState<number | null>(null);

  useEffect(() => {
    const fn = () => setScrolled(window.scrollY > 20);
    window.addEventListener("scroll", fn);
    return () => window.removeEventListener("scroll", fn);
  }, []);

  const steps = [
    { emoji: "💭", title: "分享你的 Idea", desc: "告訴 Sparky 你想做咩——遊戲、App 還是創業計劃？" },
    { emoji: "🤖", title: "AI 問答引導", desc: "Sparky 用輕鬆對話幫你把 idea 想得更清楚。" },
    { emoji: "⚙️", title: "AI 自動生成", desc: "AI 幫你生成遊戲原型或創業計劃書，無需編程！" },
    { emoji: "🚀", title: "分享成果", desc: "把你的作品分享給朋友和家人，收集反饋！" },
  ];

  const plans = [
    {
      name: "免費體驗",
      price: "HK$0",
      period: "7 日試用",
      features: ["完整功能試用 7 日", "創作 1 個遊戲 idea", "AI 問答引導"],
      cta: "免費試用",
      highlight: false,
    },
    {
      name: "小創客",
      price: "HK$98",
      period: "/月",
      features: ["無限創作次數", "10+ 遊戲模板", "即時遊戲生成", "作品集儲存", "家長進度報告"],
      cta: "立即訂閱",
      highlight: true,
    },
    {
      name: "創業家",
      price: "HK$198",
      period: "/月",
      features: ["包含小創客所有功能", "創業 Idea 工作坊", "商業計劃書生成", "導師 1 對 1 輔導（每月 1 次）"],
      cta: "立即訂閱",
      highlight: false,
    },
  ];

  const faqs = [
    { q: "需要有編程基礎嗎？", a: "完全不需要！AI 自動完成所有技術部分，學生只需回答問題。" },
    { q: "適合幾歲使用？", a: "適合 8–18 歲學生，小學生做遊戲，中學生可額外使用創業功能。" },
    { q: "支援廣東話嗎？", a: "支援！Sparky 完全支援廣東話和英文對話。" },
    { q: "如何取消訂閱？", a: "可隨時在帳戶設定中取消，無隱藏費用。" },
  ];

  return (
    <div style={{ fontFamily: "'Noto Sans HK', 'Nunito', sans-serif", color: "#2d2010", background: "#fdf8f2" }}>

      {/* ── Navbar ── */}
      <header style={{
        position: "fixed", top: 0, left: 0, right: 0, zIndex: 50,
        background: scrolled ? "rgba(255,255,255,0.96)" : "transparent",
        boxShadow: scrolled ? "0 1px 12px rgba(0,0,0,0.08)" : "none",
        transition: "all 0.3s",
        backdropFilter: scrolled ? "blur(12px)" : "none",
      }}>
        <div style={{ maxWidth: 1100, margin: "0 auto", padding: "0 24px", display: "flex", alignItems: "center", justifyContent: "space-between", height: 64 }}>
          <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
            <img src="/manus-storage/logo-icon_8f6c8dd5.png" alt="logo" style={{ width: 36, height: 36, objectFit: "contain" }} />
            <span style={{ fontFamily: "Nunito, sans-serif", fontWeight: 900, fontSize: 20, color: scrolled ? "#2d2010" : "white" }}>
              IdeaSpark <span style={{ color: "#f97316" }}>AI</span>
            </span>
          </div>
          <nav style={{ display: "flex", gap: 32, alignItems: "center" }}>
            {["功能", "如何運作", "收費"].map(label => (
              <a key={label} href={`#${label}`} style={{ fontWeight: 700, fontSize: 14, color: scrolled ? "#2d2010" : "white", textDecoration: "none", opacity: 0.85 }}>{label}</a>
            ))}
            <a href="#收費" style={{
              background: "#f97316", color: "white", fontWeight: 800, fontSize: 14,
              padding: "8px 20px", borderRadius: 999, textDecoration: "none",
              fontFamily: "Nunito, sans-serif", boxShadow: "0 3px 0 #c2540a",
            }}>免費試用</a>
          </nav>
        </div>
      </header>

      {/* ── Hero ── */}
      <section style={{
        background: "linear-gradient(135deg, #f97316 0%, #fb923c 50%, #6366f1 100%)",
        minHeight: "100vh", display: "flex", alignItems: "center", paddingTop: 80,
      }}>
        <div style={{ maxWidth: 1100, margin: "0 auto", padding: "60px 24px", display: "grid", gridTemplateColumns: "1fr 1fr", gap: 48, alignItems: "center" }}>
          <div>
            <div style={{ display: "inline-flex", alignItems: "center", gap: 8, background: "rgba(255,255,255,0.2)", color: "white", borderRadius: 999, padding: "6px 16px", fontSize: 13, fontWeight: 700, marginBottom: 20 }}>
              🇭🇰 香港首個 AI 創意教育平台
            </div>
            <h1 style={{ fontFamily: "Nunito, sans-serif", fontWeight: 900, fontSize: 52, color: "white", lineHeight: 1.2, marginBottom: 20 }}>
              你的 idea，<br />
              <span style={{ color: "#fde68a" }}>AI 幫你整出嚟！</span>
            </h1>
            <p style={{ fontSize: 17, color: "rgba(255,255,255,0.9)", lineHeight: 1.7, marginBottom: 32, maxWidth: 440 }}>
              專為香港中小學生設計，透過有趣的問答對話，<strong style={{ color: "white" }}>4 個步驟</strong>將你的創意變成真實的 AI 遊戲或創業計劃！
            </p>
            <div style={{ display: "flex", gap: 16, flexWrap: "wrap" }}>
              <a href="#收費" style={{
                background: "#fde68a", color: "#2d2010", fontWeight: 900, fontSize: 16,
                padding: "14px 32px", borderRadius: 999, textDecoration: "none",
                fontFamily: "Nunito, sans-serif", boxShadow: "0 5px 0 #ca8a04",
                display: "inline-flex", alignItems: "center", gap: 8,
              }}>🎮 免費試玩 7 日</a>
              <a href="#如何運作" style={{
                background: "rgba(255,255,255,0.15)", color: "white", fontWeight: 700, fontSize: 16,
                padding: "14px 32px", borderRadius: 999, textDecoration: "none",
                border: "2px solid rgba(255,255,255,0.4)",
              }}>▶ 睇下點玩</a>
            </div>
          </div>
          <div style={{ display: "flex", justifyContent: "center", position: "relative" }}>
            <img src="/manus-storage/hero-bg_b108b188.png" alt="hero" style={{ width: "100%", maxWidth: 460, borderRadius: 24, boxShadow: "0 20px 60px rgba(0,0,0,0.25)" }} />
            <img src="/manus-storage/mascot-sparky_2b6783e9.png" alt="Sparky" style={{ position: "absolute", bottom: -24, left: -16, width: 88, objectFit: "contain", filter: "drop-shadow(0 4px 12px rgba(0,0,0,0.2))" }} />
          </div>
        </div>
        <div style={{ position: "absolute", bottom: 0, left: 0, right: 0 }}>
          <svg viewBox="0 0 1440 60" preserveAspectRatio="none" style={{ display: "block", width: "100%", height: 60 }}>
            <path d="M0,30 C480,60 960,0 1440,30 L1440,60 L0,60 Z" fill="#fdf8f2" />
          </svg>
        </div>
      </section>

      {/* ── Stats ── */}
      <section style={{ background: "#fdf8f2", padding: "48px 24px" }}>
        <div style={{ maxWidth: 900, margin: "0 auto", display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 24 }}>
          {[
            { icon: "🎮", val: "1,200+", label: "遊戲已創作" },
            { icon: "💡", val: "500+", label: "創業 Idea 誕生" },
            { icon: "🏫", val: "30+", label: "合作學校" },
            { icon: "⭐", val: "4.9/5", label: "家長評分" },
          ].map(s => (
            <div key={s.label} style={{ background: "white", borderRadius: 20, padding: "24px 16px", textAlign: "center", boxShadow: "0 2px 16px rgba(249,115,22,0.07)" }}>
              <div style={{ fontSize: 28, marginBottom: 6 }}>{s.icon}</div>
              <div style={{ fontFamily: "Nunito, sans-serif", fontWeight: 900, fontSize: 28, color: "#f97316" }}>{s.val}</div>
              <div style={{ fontSize: 13, color: "#888", marginTop: 4 }}>{s.label}</div>
            </div>
          ))}
        </div>
      </section>

      {/* ── Features ── */}
      <section id="功能" style={{ background: "#fdf8f2", padding: "64px 24px" }}>
        <div style={{ maxWidth: 1100, margin: "0 auto" }}>
          <div style={{ textAlign: "center", marginBottom: 48 }}>
            <h2 style={{ fontFamily: "Nunito, sans-serif", fontWeight: 900, fontSize: 40, color: "#2d2010", marginBottom: 12 }}>
              創意無限，<span style={{ color: "#f97316" }}>AI 幫你實現</span>
            </h2>
            <p style={{ fontSize: 16, color: "#888" }}>從 idea 到成品，IdeaSpark AI 陪你走每一步</p>
          </div>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(2, 1fr)", gap: 24 }}>
            {[
              { icon: "🤖", title: "AI 問答引導", desc: "Sparky 用輕鬆對話方式，一步一步問你關於你的 idea，就像好朋友幫你想清楚！", color: "#f97316", img: "/manus-storage/feature-brainstorm_2436d3d5.png" },
              { icon: "🎮", title: "即時生成遊戲", desc: "完成問答後，AI 自動幫你生成一個可以即時玩的簡單遊戲，你的創意馬上變真實！", color: "#6366f1", img: "/manus-storage/feature-game_63688fb7.png" },
              { icon: "💡", title: "創業 Idea 工作坊", desc: "中學生專屬！將你的創業 idea 整理成完整計劃，包括市場分析和 Pitch 簡報。", color: "#22c55e", img: null },
              { icon: "🏆", title: "成就系統", desc: "完成每個創作都有勳章獎勵，建立你的創意作品集，向同學和家長展示成果！", color: "#f59e0b", img: null },
            ].map(f => (
              <div key={f.title} style={{ background: "white", borderRadius: 24, padding: 28, boxShadow: "0 2px 20px rgba(0,0,0,0.05)", transition: "transform 0.2s", cursor: "default" }}
                onMouseEnter={e => (e.currentTarget.style.transform = "translateY(-4px)")}
                onMouseLeave={e => (e.currentTarget.style.transform = "translateY(0)")}
              >
                <div style={{ display: "flex", alignItems: "center", gap: 14, marginBottom: 12 }}>
                  <div style={{ width: 48, height: 48, borderRadius: 14, background: `${f.color}18`, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 22 }}>{f.icon}</div>
                  <h3 style={{ fontFamily: "Nunito, sans-serif", fontWeight: 800, fontSize: 18, color: "#2d2010" }}>{f.title}</h3>
                </div>
                <p style={{ fontSize: 14, color: "#666", lineHeight: 1.7 }}>{f.desc}</p>
                {f.img && <img src={f.img} alt={f.title} style={{ width: "100%", height: 160, objectFit: "cover", borderRadius: 14, marginTop: 16 }} />}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── How It Works ── */}
      <section id="如何運作" style={{ background: "#fff7ed", padding: "64px 24px" }}>
        <div style={{ maxWidth: 900, margin: "0 auto" }}>
          <div style={{ textAlign: "center", marginBottom: 48 }}>
            <h2 style={{ fontFamily: "Nunito, sans-serif", fontWeight: 900, fontSize: 40, color: "#2d2010", marginBottom: 12 }}>
              只需 <span style={{ color: "#f97316" }}>4 個步驟</span>
            </h2>
            <p style={{ fontSize: 16, color: "#888" }}>最快 30 分鐘，從 idea 到成品！</p>
          </div>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 20 }}>
            {steps.map((s, i) => (
              <div key={s.title} style={{ textAlign: "center" }}>
                <div style={{ width: 72, height: 72, borderRadius: "50%", background: "white", border: "3px solid #f97316", display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", margin: "0 auto 16px", boxShadow: "0 4px 16px rgba(249,115,22,0.15)" }}>
                  <span style={{ fontSize: 26 }}>{s.emoji}</span>
                  <span style={{ fontSize: 10, fontWeight: 900, color: "#f97316", fontFamily: "Nunito" }}>0{i + 1}</span>
                </div>
                <h3 style={{ fontFamily: "Nunito, sans-serif", fontWeight: 800, fontSize: 15, color: "#2d2010", marginBottom: 8 }}>{s.title}</h3>
                <p style={{ fontSize: 13, color: "#777", lineHeight: 1.6 }}>{s.desc}</p>
              </div>
            ))}
          </div>

          {/* Chat demo */}
          <div style={{ maxWidth: 560, margin: "48px auto 0", background: "white", borderRadius: 24, padding: 24, boxShadow: "0 4px 24px rgba(249,115,22,0.1)" }}>
            <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 16, paddingBottom: 16, borderBottom: "1px solid #fde8d0" }}>
              <img src="/manus-storage/mascot-sparky_2b6783e9.png" alt="Sparky" style={{ width: 36, height: 36, objectFit: "contain" }} />
              <div>
                <div style={{ fontFamily: "Nunito", fontWeight: 900, fontSize: 14, color: "#f97316" }}>Sparky AI</div>
                <div style={{ fontSize: 11, color: "#22c55e", fontWeight: 700 }}>● 在線中</div>
              </div>
            </div>
            {[
              { from: "sparky", msg: "嗨！你今日想創作咩？遊戲定係創業 idea？🤖" },
              { from: "user", msg: "我想做一個太空跑酷遊戲！" },
              { from: "sparky", msg: "哇好犀利！🚀 你的主角係太空人定係外星人？" },
              { from: "user", msg: "太空人！可以用噴射背包飛！" },
            ].map((c, i) => (
              <div key={i} style={{ display: "flex", justifyContent: c.from === "user" ? "flex-end" : "flex-start", marginBottom: 10 }}>
                <div style={{
                  maxWidth: "75%", padding: "10px 14px", borderRadius: 18, fontSize: 13, lineHeight: 1.5,
                  background: c.from === "user" ? "#f97316" : "#fff7ed",
                  color: c.from === "user" ? "white" : "#2d2010",
                  borderBottomRightRadius: c.from === "user" ? 4 : 18,
                  borderBottomLeftRadius: c.from === "sparky" ? 4 : 18,
                }}>{c.msg}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── Pricing ── */}
      <section id="收費" style={{ background: "#fdf8f2", padding: "64px 24px" }}>
        <div style={{ maxWidth: 960, margin: "0 auto" }}>
          <div style={{ textAlign: "center", marginBottom: 48 }}>
            <h2 style={{ fontFamily: "Nunito, sans-serif", fontWeight: 900, fontSize: 40, color: "#2d2010", marginBottom: 12 }}>
              簡單透明，<span style={{ color: "#f97316" }}>隨時取消</span>
            </h2>
            <p style={{ fontSize: 16, color: "#888" }}>所有計劃均包含 7 日免費試用</p>
          </div>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 24, alignItems: "start" }}>
            {plans.map(p => (
              <div key={p.name} style={{
                background: p.highlight ? "#f97316" : "white",
                borderRadius: 24, padding: 28,
                boxShadow: p.highlight ? "0 16px 48px rgba(249,115,22,0.35)" : "0 2px 20px rgba(0,0,0,0.05)",
                transform: p.highlight ? "scale(1.04)" : "scale(1)",
                position: "relative",
              }}>
                {p.highlight && (
                  <div style={{ position: "absolute", top: -14, left: "50%", transform: "translateX(-50%)", background: "#fde68a", color: "#92400e", fontWeight: 900, fontSize: 12, padding: "4px 16px", borderRadius: 999, fontFamily: "Nunito", whiteSpace: "nowrap" }}>
                    🔥 最受歡迎
                  </div>
                )}
                <div style={{ fontFamily: "Nunito", fontWeight: 900, fontSize: 20, color: p.highlight ? "white" : "#2d2010", marginBottom: 4 }}>{p.name}</div>
                <div style={{ display: "flex", alignItems: "baseline", gap: 4, marginBottom: 20 }}>
                  <span style={{ fontFamily: "Nunito", fontWeight: 900, fontSize: 36, color: p.highlight ? "#fde68a" : "#f97316" }}>{p.price}</span>
                  <span style={{ fontSize: 13, color: p.highlight ? "rgba(255,255,255,0.7)" : "#aaa" }}>{p.period}</span>
                </div>
                <ul style={{ listStyle: "none", padding: 0, margin: "0 0 24px", display: "flex", flexDirection: "column", gap: 8 }}>
                  {p.features.map(f => (
                    <li key={f} style={{ fontSize: 13, color: p.highlight ? "rgba(255,255,255,0.9)" : "#555", display: "flex", alignItems: "center", gap: 8 }}>
                      <span style={{ color: p.highlight ? "#fde68a" : "#22c55e", fontWeight: 700 }}>✓</span> {f}
                    </li>
                  ))}
                </ul>
                <button style={{
                  width: "100%", padding: "12px", borderRadius: 14, border: "none",
                  background: p.highlight ? "#fde68a" : "#f97316",
                  color: p.highlight ? "#92400e" : "white",
                  fontFamily: "Nunito", fontWeight: 900, fontSize: 15, cursor: "pointer",
                  boxShadow: p.highlight ? "0 3px 0 #ca8a04" : "0 3px 0 #c2540a",
                  transition: "transform 0.15s",
                }}
                  onMouseEnter={e => (e.currentTarget.style.transform = "translateY(-2px)")}
                  onMouseLeave={e => (e.currentTarget.style.transform = "translateY(0)")}
                  onMouseDown={e => (e.currentTarget.style.transform = "translateY(2px)")}
                  onMouseUp={e => (e.currentTarget.style.transform = "translateY(0)")}
                >{p.cta}</button>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── FAQ ── */}
      <section id="FAQ" style={{ background: "#fff7ed", padding: "64px 24px" }}>
        <div style={{ maxWidth: 680, margin: "0 auto" }}>
          <h2 style={{ fontFamily: "Nunito, sans-serif", fontWeight: 900, fontSize: 36, color: "#2d2010", textAlign: "center", marginBottom: 36 }}>
            常見問題 <span style={{ color: "#f97316" }}>❓</span>
          </h2>
          <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
            {faqs.map((f, i) => (
              <div key={i} style={{ background: "white", borderRadius: 18, overflow: "hidden", boxShadow: "0 1px 8px rgba(0,0,0,0.05)" }}>
                <button
                  onClick={() => setOpenFaq(openFaq === i ? null : i)}
                  style={{ width: "100%", padding: "18px 20px", display: "flex", justifyContent: "space-between", alignItems: "center", background: "none", border: "none", cursor: "pointer", textAlign: "left" }}
                >
                  <span style={{ fontFamily: "Nunito", fontWeight: 800, fontSize: 15, color: "#2d2010" }}>{f.q}</span>
                  <span style={{ width: 28, height: 28, borderRadius: "50%", background: "#f97316", color: "white", display: "flex", alignItems: "center", justifyContent: "center", fontWeight: 900, fontSize: 18, flexShrink: 0, transition: "transform 0.2s", transform: openFaq === i ? "rotate(45deg)" : "none" }}>+</span>
                </button>
                {openFaq === i && (
                  <div style={{ padding: "0 20px 18px", fontSize: 14, color: "#666", lineHeight: 1.7 }}>{f.a}</div>
                )}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── CTA ── */}
      <section style={{ background: "linear-gradient(135deg, #f97316, #6366f1)", padding: "72px 24px", textAlign: "center" }}>
        <img src="/manus-storage/mascot-sparky_2b6783e9.png" alt="Sparky" style={{ width: 80, marginBottom: 16, objectFit: "contain" }} />
        <h2 style={{ fontFamily: "Nunito", fontWeight: 900, fontSize: 38, color: "white", marginBottom: 12 }}>
          準備好點燃你的創意火花了嗎？
        </h2>
        <p style={{ fontSize: 16, color: "rgba(255,255,255,0.85)", marginBottom: 32 }}>
          立即免費試用 7 日，讓 Sparky 幫你把 idea 變成真實！
        </p>
        <a href="#收費" style={{
          background: "#fde68a", color: "#92400e", fontWeight: 900, fontSize: 18,
          padding: "16px 40px", borderRadius: 999, textDecoration: "none",
          fontFamily: "Nunito", boxShadow: "0 5px 0 #ca8a04", display: "inline-block",
        }}>🎮 免費試玩 7 日</a>
      </section>

      {/* ── Footer ── */}
      <footer style={{ background: "#1c1208", padding: "36px 24px", textAlign: "center" }}>
        <div style={{ display: "flex", alignItems: "center", justifyContent: "center", gap: 10, marginBottom: 12 }}>
          <img src="/manus-storage/logo-icon_8f6c8dd5.png" alt="logo" style={{ width: 28, objectFit: "contain" }} />
          <span style={{ fontFamily: "Nunito", fontWeight: 900, fontSize: 18, color: "white" }}>
            IdeaSpark <span style={{ color: "#f97316" }}>AI</span>
          </span>
        </div>
        <p style={{ fontSize: 13, color: "#666", marginBottom: 12 }}>香港首個 AI 創意教育平台 · 讓每個小朋友的 idea 都能成真</p>
        <p style={{ fontSize: 12, color: "#444" }}>© 2026 IdeaSpark AI. 版權所有。</p>
      </footer>
    </div>
  );
}
